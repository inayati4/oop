namespace CollegeManagement.Models;

public class Group
{
    private readonly List<Student> _students = new();
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Course { get; set; }
    public IReadOnlyList<Student> Students => _students.AsReadOnly();

    public bool AddStudent(Student student)
    {
        if (student is null || _students.Any(s => s.StudentId == student.StudentId && student.StudentId != 0)) return false;
        _students.Add(student);
        return true;
    }

    public bool RemoveStudent(int studentId)
    {
        var student = _students.FirstOrDefault(s => s.StudentId == studentId);
        return student != null && _students.Remove(student);
    }
}
