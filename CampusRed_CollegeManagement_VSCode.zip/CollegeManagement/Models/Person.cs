namespace CollegeManagement.Models;

// protected өрістер мұрагер Student және Teacher кластарына қолжетімді.
public class Person
{
    protected string _name;
    protected string _surname;
    protected int _age;

    public Person(string name, string surname, int age)
    {
        _name = name;
        _surname = surname;
        _age = age;
    }

    protected void DisplayBasicInfo()
    {
        // Негізгі ақпаратты мұрагер кластар өз әдістерінде пайдаланады.
    }

    protected internal string GetFullName() => $"{_name} {_surname}";

    private protected int CalculateStatistics() => _age;
}
