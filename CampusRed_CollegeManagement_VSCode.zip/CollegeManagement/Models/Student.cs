namespace CollegeManagement.Models;

public class Student : Person
{
    private string _group;
    public int StudentId { get; private set; }
    public string Name { get => _name; set => _name = value; }
    public string Surname { get => _surname; set => _surname = value; }
    public int Age { get => _age; private set => SetAge(value); }
    public string Group { get => _group; set => _group = value; }

    public Student(string name, string surname, int age, string group, int studentId = 0)
        : base(name, surname, age)
    {
        _group = group;
        StudentId = studentId;
        ValidateStudentData();
    }

    public void SetAge(int age)
    {
        if (age < 15 || age > 70) throw new ArgumentOutOfRangeException(nameof(age), "Жас 15 пен 70 аралығында болуы керек.");
        _age = age;
    }

    private void ValidateStudentData()
    {
        if (string.IsNullOrWhiteSpace(_name) || string.IsNullOrWhiteSpace(_surname) || string.IsNullOrWhiteSpace(_group))
            throw new ArgumentException("Студенттің аты, тегі және тобы бос болмауы керек.");
        if (_age < 15 || _age > 70) throw new ArgumentException("Студент жасы 15 пен 70 аралығында болуы керек.");
    }

    public string GetStudentInfo()
    {
        DisplayBasicInfo();
        return $"#{StudentId} — {GetFullName()}, жас: {_age}, топ: {_group}";
    }

    public string DisplayInfo() => GetStudentInfo();
}
