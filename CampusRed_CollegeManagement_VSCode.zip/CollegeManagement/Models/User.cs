namespace CollegeManagement.Models;

public class User
{
    protected string UserName;
    private string Password;

    public User(string userName, string password)
    {
        UserName = userName;
        Password = password;
    }

    public bool Login(string login, string password) =>
        UserName == login && Password == password;

    public virtual string Role => "User";
    public string SafeInfo() => $"{UserName} ({Role})";
}

public class Admin : User
{
    public Admin(string login, string password) : base(login, password) { }
    public override string Role => "Admin";
}
