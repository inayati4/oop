namespace CollegeManagement.Models;

public class Grade
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public string StudentName { get; set; } = "";
    public string Subject { get; set; } = "";
    public int Value { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
}

public class GradeBook
{
    private readonly List<int> _grades = new();
    public IReadOnlyList<int> Grades => _grades.AsReadOnly();
    public void AddGrade(int grade)
    {
        if (grade < 2 || grade > 5) throw new ArgumentOutOfRangeException(nameof(grade), "Баға 2-ден 5-ке дейін болуы керек.");
        _grades.Add(grade);
    }
    public bool RemoveGrade(int grade) => _grades.Remove(grade);
}
