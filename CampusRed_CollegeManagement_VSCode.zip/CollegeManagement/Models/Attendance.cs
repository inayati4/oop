namespace CollegeManagement.Models;

public class Attendance
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public string StudentName { get; set; } = "";
    public DateTime Date { get; set; } = DateTime.Today;
    public bool IsPresent { get; set; }
}
