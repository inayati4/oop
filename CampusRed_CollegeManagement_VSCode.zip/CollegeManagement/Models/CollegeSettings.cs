namespace CollegeManagement.Models;

// internal: тек осы жоба (assembly) ішінде қолжетімді.
internal class CollegeSettings
{
    public string CollegeName { get; private set; } = "College Management";
    public string AcademicYear { get; private set; } = "2026–2027";
    internal void Update(string name, string year)
    {
        CollegeName = name;
        AcademicYear = year;
    }
}
