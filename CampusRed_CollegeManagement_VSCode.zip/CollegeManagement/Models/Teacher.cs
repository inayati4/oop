namespace CollegeManagement.Models;

public class Teacher : Person
{
    private string _subject;
    private int _experience;

    public int Id { get; set; }
    public string Name { get => _name; set => _name = value; }
    public string Surname { get => _surname; set => _surname = value; }
    public int Age { get => _age; set => _age = value; }
    public string Subject { get => _subject; set => _subject = value; }
    public int Experience { get => _experience; private set => _experience = value; }

    public Teacher(string name, string surname, int age, string subject, int experience, int id = 0)
        : base(name, surname, age)
    {
        _subject = subject;
        _experience = experience;
        Id = id;
    }

    public void UpdateExperience(int years)
    {
        if (years < 0 || years > 60) throw new ArgumentOutOfRangeException(nameof(years));
        _experience = years;
    }

    public string GetTeacherInfo()
    {
        DisplayBasicInfo();
        return $"{GetFullName()} — пәні: {_subject}, еңбек өтілі: {_experience} жыл";
    }
}
