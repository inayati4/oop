namespace CollegeManagement.Models;

public class UserAccount
{
    private readonly string _login;
    private readonly string _password;
    public UserAccount(string login, string password) { _login = login; _password = password; }
    public bool Login(string login, string password) => _login == login && _password == password;
    public void Logout() { }
    public string GetInfo() => $"Пайдаланушы: {_login}"; // пароль ешқашан көрсетілмейді
}
