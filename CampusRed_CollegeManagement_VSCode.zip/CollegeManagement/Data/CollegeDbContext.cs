using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Data;

public class CollegeDbContext : DbContext
{
    public CollegeDbContext(DbContextOptions<CollegeDbContext> options) : base(options) { }
    public DbSet<StudentRecord> Students => Set<StudentRecord>();
    public DbSet<TeacherRecord> Teachers => Set<TeacherRecord>();
    public DbSet<GroupRecord> Groups => Set<GroupRecord>();
    public DbSet<Grade> Grades => Set<Grade>();
    public DbSet<Attendance> Attendances => Set<Attendance>();
}

public class StudentRecord
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Surname { get; set; } = "";
    public int Age { get; set; }
    public string GroupName { get; set; } = "";
}
public class TeacherRecord
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Surname { get; set; } = "";
    public string Subject { get; set; } = "";
    public int Experience { get; set; }
}
public class GroupRecord
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Course { get; set; }
}
