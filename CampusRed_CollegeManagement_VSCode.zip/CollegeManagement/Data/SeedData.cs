using CollegeManagement.Models;

namespace CollegeManagement.Data;

public static class SeedData
{
    public static void Initialize(CollegeDbContext db)
    {
        if (!db.Students.Any())
        {
            db.Students.AddRange(
                new StudentRecord { Name = "Айдана", Surname = "Серік", Age = 18, GroupName = "ИС-21" },
                new StudentRecord { Name = "Әли", Surname = "Нұрлан", Age = 19, GroupName = "ИС-21" },
                new StudentRecord { Name = "Дана", Surname = "Ермек", Age = 20, GroupName = "ПО-22" });
        }
        if (!db.Teachers.Any())
            db.Teachers.AddRange(
                new TeacherRecord { Name = "Марат", Surname = "Омаров", Subject = "Информатика", Experience = 8 },
                new TeacherRecord { Name = "Алия", Surname = "Қасымова", Subject = "Бағдарламалау", Experience = 5 });
        if (!db.Groups.Any())
            db.Groups.AddRange(
                new GroupRecord { Name = "ИС-21", Course = 2 },
                new GroupRecord { Name = "ПО-22", Course = 2 });
        db.SaveChanges();
    }
}
