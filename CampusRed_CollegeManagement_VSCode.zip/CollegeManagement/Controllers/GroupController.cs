using CollegeManagement.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;
public class GroupController : Controller
{
    private readonly CollegeDbContext _db;
    public GroupController(CollegeDbContext db) => _db = db;
    public async Task<IActionResult> Index() => View(await _db.Groups.OrderBy(g => g.Name).ToListAsync());
}
