using CollegeManagement.Data;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;
public class StudentController : Controller
{
    private readonly StudentService _service;
    public StudentController(StudentService service) => _service = service;
    public async Task<IActionResult> Index() => View(await _service.GetAllAsync());
    [HttpGet] public IActionResult Create() => View();
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(StudentRecord model)
    {
        if (!ModelState.IsValid) return View(model);
        try { await _service.AddAsync(model); return RedirectToAction(nameof(Index)); }
        catch (Exception ex) { ModelState.AddModelError("", ex.Message); return View(model); }
    }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id) { await _service.DeleteAsync(id); return RedirectToAction(nameof(Index)); }
}
