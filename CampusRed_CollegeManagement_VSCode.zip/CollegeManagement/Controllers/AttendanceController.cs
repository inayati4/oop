using CollegeManagement.Data;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;
public class AttendanceController : Controller
{
    private readonly AttendanceManager _manager;
    private readonly CollegeDbContext _db;
    public AttendanceController(AttendanceManager manager, CollegeDbContext db) { _manager = manager; _db = db; }
    public async Task<IActionResult> Index()
    {
        ViewBag.Students = await _db.Students.OrderBy(s => s.Surname).ToListAsync();
        ViewBag.Stats = await _manager.GetStatisticsAsync();
        return View(await _manager.GetAllAsync());
    }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(int studentId, DateTime date, bool present)
    {
        var s = await _db.Students.FindAsync(studentId);
        if (s != null) await _manager.AddAsync(s.Id, s.Name + " " + s.Surname, date == default ? DateTime.Today : date, present);
        return RedirectToAction(nameof(Index));
    }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Update(int id, bool present) { await _manager.UpdateAsync(id, present); return RedirectToAction(nameof(Index)); }
}
