using CollegeManagement.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;
public class TeacherController : Controller
{
    private readonly CollegeDbContext _db;
    public TeacherController(CollegeDbContext db) => _db = db;
    public async Task<IActionResult> Index() => View(await _db.Teachers.OrderBy(t => t.Surname).ToListAsync());
    [HttpGet] public IActionResult Create() => View();
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(TeacherRecord model)
    {
        if (ModelState.IsValid) { _db.Teachers.Add(model); await _db.SaveChangesAsync(); return RedirectToAction(nameof(Index)); }
        return View(model);
    }
}
