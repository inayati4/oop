using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class AccountController : Controller
{
    [HttpGet] public IActionResult Login() => View();
    [HttpPost] [ValidateAntiForgeryToken]
    public IActionResult Login(string login, string password)
    {
        var account = new UserAccount("admin", "Admin123!");
        if (account.Login(login ?? "", password ?? ""))
        {
            HttpContext.Session.SetString("User", login);
            return RedirectToAction("Index", "Home");
        }
        ViewBag.Error = "Логин немесе пароль қате.";
        return View();
    }
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}
