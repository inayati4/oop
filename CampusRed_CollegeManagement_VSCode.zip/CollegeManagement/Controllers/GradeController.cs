using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;
public class GradeController : Controller
{
    private readonly CollegeDbContext _db;
    public GradeController(CollegeDbContext db) => _db = db;
    public async Task<IActionResult> Index()
    {
        ViewBag.Students = await _db.Students.OrderBy(s => s.Surname).ToListAsync();
        return View(await _db.Grades.OrderByDescending(g => g.Date).ToListAsync());
    }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(int studentId, string subject, int value)
    {
        if (value < 2 || value > 5) TempData["Error"] = "Баға 2 мен 5 аралығында болуы керек.";
        else
        {
            var s = await _db.Students.FindAsync(studentId);
            if (s != null)
            {
                _db.Grades.Add(new Grade { StudentId = s.Id, StudentName = s.Name + " " + s.Surname, Subject = subject, Value = value, Date = DateTime.Today });
                await _db.SaveChangesAsync();
            }
        }
        return RedirectToAction(nameof(Index));
    }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _db.Grades.FindAsync(id);
        if (item != null) { _db.Grades.Remove(item); await _db.SaveChangesAsync(); }
        return RedirectToAction(nameof(Index));
    }
}
