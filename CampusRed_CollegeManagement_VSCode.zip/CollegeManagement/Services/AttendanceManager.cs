using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public class AttendanceManager
{
    private readonly CollegeDbContext _db;
    public AttendanceManager(CollegeDbContext db) => _db = db;
    public async Task AddAsync(int studentId, string studentName, DateTime date, bool present)
    {
        _db.Attendances.Add(new Attendance { StudentId = studentId, StudentName = studentName, Date = date.Date, IsPresent = present });
        await _db.SaveChangesAsync();
    }
    public async Task UpdateAsync(int id, bool present)
    {
        var row = await _db.Attendances.FindAsync(id);
        if (row != null) { row.IsPresent = present; await _db.SaveChangesAsync(); }
    }
    public Task<List<Attendance>> GetAllAsync() => _db.Attendances.OrderByDescending(a => a.Date).ToListAsync();
    public async Task<string> GetStatisticsAsync()
    {
        var all = await _db.Attendances.CountAsync();
        var present = await _db.Attendances.CountAsync(a => a.IsPresent);
        return all == 0 ? "Әзірге дерек жоқ" : $"Қатысқан: {present}/{all} ({present * 100 / all}%)";
    }
}
