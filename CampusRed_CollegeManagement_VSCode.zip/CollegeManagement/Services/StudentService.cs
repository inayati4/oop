using CollegeManagement.Data;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public class StudentService
{
    private readonly CollegeDbContext _db;
    public StudentService(CollegeDbContext db) => _db = db;
    public Task<List<StudentRecord>> GetAllAsync() => _db.Students.OrderBy(s => s.Surname).ToListAsync();
    public async Task AddAsync(StudentRecord student)
    {
        if (student.Age < 15 || student.Age > 70) throw new ArgumentException("Жас 15 пен 70 аралығында болуы керек.");
        _db.Students.Add(student);
        await _db.SaveChangesAsync();
    }
    public async Task DeleteAsync(int id)
    {
        var item = await _db.Students.FindAsync(id);
        if (item != null) { _db.Students.Remove(item); await _db.SaveChangesAsync(); }
    }
}
