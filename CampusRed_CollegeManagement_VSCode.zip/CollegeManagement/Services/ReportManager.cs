namespace CollegeManagement.Services;

public class ReportManager
{
    protected internal string GenerateReport(int students, int teachers) =>
        $"Есеп: студенттер — {students}, оқытушылар — {teachers}.";
}
