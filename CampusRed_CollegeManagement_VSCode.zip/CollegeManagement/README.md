# CampusRed — College Management System

A responsive English-language ASP.NET Core MVC college management website with a clean white-and-red interface.

## Requirements
- .NET 8 SDK
- Visual Studio Code
- C# Dev Kit extension (recommended)

## Run in VS Code
1. Extract this ZIP archive.
2. Open the `CollegeManagement` folder in VS Code (`File → Open Folder`).
3. Open a terminal (`Terminal → New Terminal`).
4. Run:

```bash
dotnet --version
dotnet restore
dotnet run
```

5. Open the `http://localhost:xxxx` or `https://localhost:xxxx` address shown in the terminal.

If port is busy:
```bash
dotnet run --urls http://localhost:5055
```

## Demo sign-in
- Username: `admin`
- Password: `Admin123!`

## Included modules
- Dashboard with overview cards, quick actions and college snapshot
- Student directory: list, add, delete, search, age validation
- Faculty directory: list and add teachers
- Groups and classes overview
- Gradebook: add and delete grades (2–5 validation)
- Attendance: create records, change present/absent status, attendance statistics
- SQLite local database, seeded with sample records
- Custom CampusRed SVG logo and responsive white/red theme

## Project structure
- `Controllers/` — MVC controllers
- `Models/` — domain models and access-modifier exercises
- `Services/` — application services
- `Views/` — English website pages
- `Data/` — EF Core SQLite context and sample data
- `wwwroot/css/` — site styles
- `wwwroot/images/` — logo

## Notes
This is a learning/demo application. Login is a simple hard-coded demonstration, not production authentication. For real deployment, use ASP.NET Core Identity, password hashing, role authorization, anti-forgery protection on every form, stronger validation and database migrations.
